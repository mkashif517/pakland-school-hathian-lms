# Pakland School Hathian

Static school website (single index.html). Deploy on Vercel with Framework Preset: Other, no build command, output directory: ./
